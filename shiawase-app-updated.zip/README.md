# しあわせの散歩道 (iOSアプリ化)

1. このフォルダの中身をそのままGitHubの新しいリポジトリ（mainブランチ）にpush
2. リポジトリの Actions タブ → 「Build IPA」→ Run workflow（pushでも自動で動く）
3. 完了後、Artifacts の `shiawase-ipa` から `shiawase-unsigned.ipa` をダウンロード

## 注意
- 出てくるIPAは「署名なし」です。そのままではiPhoneに入りません。
  Sideloadly / AltStore / TrollStore などで自分のApple IDで署名して入れてください。
- App Storeに出す場合は Apple Developer Program（有料）が必要で、署名・証明書の設定をワークフローに足します。
- ゲーム本体は `www/index.html`。three.js はビルド時に npm から `www/three.min.js` へコピーされます。
- アプリ名・ID は `capacitor.config.json` の appName / appId で変更できます。

## 今回の追加機能
- 学校の時間割を最大6限・15:00下校に設定
- 広い公園、すべり台、ブランコ、タコ型遊具、砂場、池、親子NPC
- 視線方向を基準にしたアクション選択
- 頭上の名前表示／画面上の文字表示の個別設定
- FOV調整、春夏秋冬の季節設定
- パン屋、工程式パン作りチュートリアル、販売と食べる機能

